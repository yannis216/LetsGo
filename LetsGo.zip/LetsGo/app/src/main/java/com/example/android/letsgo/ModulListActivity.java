package com.example.android.letsgo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ModulListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modul_list);
    }
}
